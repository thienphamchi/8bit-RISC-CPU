// =====================================================================
//  FILE        : tb/tb_risc8_5stage.v
//  MODULE      : tb_risc8_5stage   (TESTBENCH - simulation only)
//  PROJECT     : 8-bit RISC Processor Core with 5-Stage Pipeline
// ---------------------------------------------------------------------
//  WHAT THIS FILE DOES
//    1. Generates clock and reset.
//    2. Runs the program built into imem.v until the core halts.
//    3. Prints the instruction in each of the 5 stages every cycle
//       (IF, ID, EX, MEM, WB), as text such as "ADD  R2,R2,R1".
//    4. Checks registers, memory and flags -> PASS / FAIL.
//    5. Reports cycles, instructions, CPI, stalls, flushes, forwards.
//    6. Dumps risc8_5stage.vcd for GTKWave.
//
//  MODULES CALLED (instantiated) IN THIS FILE
//    risc8_5stage_core  from rtl/risc8_5stage_core.v  -> instance "dut"
//
//  INTERNAL SIGNALS READ (hierarchical references, simulation only)
//    dut.* pipeline registers, stall, take_branch, fwd_*_sel, flags
//                                            -> rtl/risc8_5stage_core.v
//    dut.u_rf.r[...]      register array     -> rtl/regfile.v
//    dut.u_dmem.mem[...]  data memory array  -> rtl/dmem.v
//
//  FILES NEEDED AT RUN TIME
//    none: the program is built into imem.v
//
//  HOW TO RUN (Vivado)
//    Set tb_risc8_5stage as simulation top, Run Behavioral Simulation.
//    The test stops by itself at 545 ns with "*** ALL TESTS PASSED ***".
// =====================================================================

`timescale 1ns/1ps

module tb_risc8_5stage;

    reg clk = 0;
    reg rst = 1;
    wire       halted;
    wire [7:0] pc;
    wire [1:0] flags;        // {Z, C} from the core
    wire       instr_done;   // 1 when an instruction finishes WB

    // -----------------------------------------------------------------
    // CALL: module risc8_5stage_core from rtl/risc8_5stage_core.v
    // -----------------------------------------------------------------
    risc8_5stage_core dut (
        .clk    (clk),
        .rst    (rst),
        .halted     (halted),
        .pc_out     (pc),
        .flags_out  (flags),
        .instr_done (instr_done)
    );

    // 100 MHz clock (10 ns period): flip clk every 5 ns, forever
    initial forever #5 clk = ~clk;

    // -----------------------------------------------------------------
    // Counters
    // -----------------------------------------------------------------
    integer cycles  = 0;   // cycles from reset release until halted
    integer retired = 0;   // valid instructions that reached WB
    integer stalls  = 0;   // load-use stall cycles
    integer flushes = 0;   // taken branches (each flushes 2 instructions)
    integer fwds    = 0;   // EX operands supplied by forwarding
    integer errors  = 0;

    // -----------------------------------------------------------------
    // Disassembler helpers (simulation only): turn a 16-bit instruction
    // into a fixed-width text such as "ADD  R2,R2,R1   " (17 characters).
    // Every piece has a fixed width, so the columns always line up.
    // -----------------------------------------------------------------
    function [7:0] hexch;               // 4-bit value -> ASCII '0'..'F'
        input [3:0] n;
        hexch = (n < 4'd10) ? (8'h30 + {4'b0, n}) : (8'h37 + {4'b0, n});
    endfunction

    function [7:0] regch;               // register number -> ASCII '0'..'7'
        input [2:0] n;
        regch = 8'h30 + {5'b0, n};
    endfunction

    // verilator lint_off BLKSEQ
    function [8*17-1:0] dis;
        input [15:0] w;
        reg [8*5-1:0]  mn;              // mnemonic, 5 characters
        reg [8*12-1:0] ops;             // operands, 12 characters
        reg [2:0] rd, rs1, rs2;
        reg [7:0] imm;
        begin
            rd = w[11:9]; rs1 = w[8:6]; rs2 = w[5:3]; imm = w[7:0];
            case (w[15:12])
                4'h0: begin mn = "NOP  "; ops = "            "; end
                4'h1: begin mn = "ADD  "; ops = {"R", regch(rd), ",R", regch(rs1), ",R", regch(rs2), "    "}; end
                4'h2: begin mn = "SUB  "; ops = {"R", regch(rd), ",R", regch(rs1), ",R", regch(rs2), "    "}; end
                4'h3: begin mn = "AND  "; ops = {"R", regch(rd), ",R", regch(rs1), ",R", regch(rs2), "    "}; end
                4'h4: begin mn = "OR   "; ops = {"R", regch(rd), ",R", regch(rs1), ",R", regch(rs2), "    "}; end
                4'h5: begin mn = "XOR  "; ops = {"R", regch(rd), ",R", regch(rs1), ",R", regch(rs2), "    "}; end
                4'h6: begin mn = "SHL  "; ops = {"R", regch(rd), ",R", regch(rs1), "       "}; end
                4'h7: begin mn = "SHR  "; ops = {"R", regch(rd), ",R", regch(rs1), "       "}; end
                4'h8: begin mn = "LDI  "; ops = {"R", regch(rd), ",0x", hexch(imm[7:4]), hexch(imm[3:0]), "     "}; end
                4'h9: begin mn = "ADDI "; ops = {"R", regch(rd), ",0x", hexch(imm[7:4]), hexch(imm[3:0]), "     "}; end
                4'hA: begin mn = "LD   "; ops = {"R", regch(rd), ",[R", regch(rs1), "]     "}; end
                4'hB: begin mn = "ST   "; ops = {"R", regch(rd), ",[R", regch(rs1), "]     "}; end
                4'hC: begin mn = "JMP  "; ops = {"0x", hexch(imm[7:4]), hexch(imm[3:0]), "        "}; end
                4'hD: begin mn = "BZ   "; ops = {"0x", hexch(imm[7:4]), hexch(imm[3:0]), "        "}; end
                4'hE: begin mn = "BNZ  "; ops = {"0x", hexch(imm[7:4]), hexch(imm[3:0]), "        "}; end
                default: begin mn = "HLT  "; ops = "            "; end
            endcase
            dis = {mn, ops};
        end
    endfunction

    // verilator lint_on BLKSEQ

    // Text of one stage: the instruction, or "(bubble)" when the slot is empty.
    function [8*17-1:0] stage_txt;
        input        valid;
        input [15:0] w;
        stage_txt = valid ? dis(w) : "(bubble)         ";
    endfunction

    // Write-back text "R3<=0c" (6 characters), blank when nothing is written.
    function [8*6-1:0] wb_txt;
        input        we;
        input [2:0]  rd;
        input [7:0]  data;
        wb_txt = we ? {"R", regch(rd), "<=", hexch(data[7:4]), hexch(data[3:0])} : "      ";
    endfunction

    // -----------------------------------------------------------------
    // Shadow copies of the instruction word in EX, MEM and WB.
    // The core only carries control bits down the pipeline, not the
    // instruction itself, so the testbench follows it with its own
    // registers (same move/hold/bubble rules as the core). The core is
    // NOT modified.
    // -----------------------------------------------------------------
    reg [15:0] sh_ex, sh_mem, sh_wb;

    always @(posedge clk) begin
        if (rst) begin
            sh_ex <= 16'h0000; sh_mem <= 16'h0000; sh_wb <= 16'h0000;
        end else if (!halted) begin
            // ID -> EX moves only when the core does not flush or stall
            if (!(dut.take_branch || dut.fetch_stop || dut.stall))
                sh_ex <= dut.ifid_instr;
            sh_mem <= sh_ex;     // EX  -> MEM  (always moves)
            sh_wb  <= sh_mem;    // MEM -> WB   (always moves)
        end
    end

    // -----------------------------------------------------------------
    // Per-cycle monitor: one line per clock cycle, one column per stage
    // -----------------------------------------------------------------
    always @(posedge clk) if (!rst && !halted) begin
        cycles <= cycles + 1;
        if (instr_done)      retired <= retired + 1;
        if (dut.stall)       stalls  <= stalls  + 1;
        if (dut.take_branch) flushes <= flushes + 1;
        // hazard_unit.v only forwards into operands that are really used
        if (dut.idex_valid && (dut.fwd_a_sel != 2'b00 || dut.fwd_b_sel != 2'b00))
            fwds <= fwds + 1;

        // IF is shown as "(flushed)" when the fetched instruction is thrown away
        $display("t=%6t PC=%02h | IF:%s | ID:%s | EX:%s | MEM:%s | WB:%s %s | Z=%b C=%b%s%s%s",
                 $time, pc,
                 (dut.take_branch || dut.fetch_stop) ? "(flushed)        " : dis(dut.if_instr),
                 stage_txt(dut.ifid_valid,  dut.ifid_instr),
                 stage_txt(dut.idex_valid,  sh_ex),
                 stage_txt(dut.exmem_valid, sh_mem),
                 stage_txt(dut.memwb_valid, sh_wb),
                 wb_txt(dut.memwb_reg_we, dut.memwb_rd, dut.memwb_data),
                 flags[1], flags[0],
                 dut.stall       ? " STALL"            : "",
                 dut.take_branch ? " BRANCH->flush 2" : "",
                 (dut.idex_valid && (dut.fwd_a_sel != 2'b00 || dut.fwd_b_sel != 2'b00)) ? " fwd" : "");
    end

    // -----------------------------------------------------------------
    // TASK: check one register (array inside rtl/regfile.v)
    // -----------------------------------------------------------------
    task check_reg(input [2:0] r, input [7:0] exp);
        if (dut.u_rf.r[r] !== exp) begin
            $display("FAIL  R%0d = %02h, expected %02h", r, dut.u_rf.r[r], exp);
            errors = errors + 1;
        end else
            $display("PASS  R%0d = %02h", r, exp);
    endtask

    // -----------------------------------------------------------------
    // Main sequence
    // -----------------------------------------------------------------
    initial begin
        $dumpfile("risc8_5stage.vcd");
        $dumpvars(0, tb_risc8_5stage);

        #22 rst = 0;            // release reset after ~2 cycles
        wait (halted);          // run until HLT leaves the pipeline
        @(posedge clk); @(posedge clk);

        // Expected values come from the program built into imem.v
        $display("\n------------- register / memory check -------------");
        check_reg(1, 8'h00);  check_reg(2, 8'h0F);
        check_reg(3, 8'h01);  check_reg(4, 8'h20);
        check_reg(5, 8'h00);  check_reg(6, 8'h66);
        check_reg(7, 8'h00);

        if (dut.u_dmem.mem[8'h20] !== 8'h0F) begin
            $display("FAIL  MEM[20] = %02h", dut.u_dmem.mem[8'h20]); errors = errors + 1;
        end else $display("PASS  MEM[20] = 0F");

        if (flags !== 2'b11) begin
            $display("FAIL  flags Z=%b C=%b", flags[1], flags[0]); errors = errors + 1;
        end else $display("PASS  flags Z=1 C=1");

        $display("\ncycles=%0d  instructions=%0d  CPI=%0.2f  load-use stalls=%0d  taken branches=%0d  forwards=%0d",
                 cycles, retired, cycles * 1.0 / retired, stalls, flushes, fwds);
        if (errors == 0) $display("*** ALL TESTS PASSED ***");
        else             $display("*** %0d TEST(S) FAILED ***", errors);
        $finish;
    end

    // Watchdog: stop if the CPU never halts
    initial begin #20000 $display("TIMEOUT"); $finish; end

endmodule
