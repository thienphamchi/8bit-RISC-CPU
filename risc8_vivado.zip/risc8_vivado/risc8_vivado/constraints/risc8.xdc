## =====================================================================
##  FILE   : risc8.xdc  -  constraints for risc8_5stage_core
##  DEVICE : XA7S100-1FGGA676Q  (Vivado part: xa7s100fgga676-1Q)
## ---------------------------------------------------------------------
##  PART 1 is complete: it is enough for synthesis, implementation and
##  the timing report (WNS).
##  PART 2 (pins) must be filled in from YOUR board schematic. The
##  XA7S100 is a bare FPGA, so the clock / button / LED pins depend
##  entirely on the board. Without PART 2 you can NOT generate a bitstream.
## =====================================================================

## ---------------------------------------------------------------------
## PART 1 : clock and configuration
## ---------------------------------------------------------------------
## Clock target: 100 MHz (10 ns). If your board oscillator has another
## frequency, put its real period here (50 MHz -> 20.000, 200 MHz -> 5.000).
create_clock -name sys_clk -period 10.000 [get_ports clk]

## Configuration bank voltage: use the VCCO of the configuration bank (bank 0)
## on your board. 3.3 V is the most common value; 1.8 V is the other option.
set_property CFGBVS VCCO        [current_design]
set_property CONFIG_VOLTAGE 3.3 [current_design]

## ---------------------------------------------------------------------
## PART 2 : pin assignments (FILL IN, then remove the leading ## )
##   PACKAGE_PIN : ball name from the board schematic (e.g. "AB12")
##   IOSTANDARD  : must match the VCCO of that bank (LVCMOS33 / LVCMOS18 ...)
## ---------------------------------------------------------------------
## Clock input (board oscillator)
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports clk]

## Reset input (push button). rst is ACTIVE HIGH: if your button is
## active-low, invert it in a small top wrapper.
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports rst]

## Outputs (LEDs or header pins)
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports halted]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports instr_done]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports {flags_out[0]}]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports {flags_out[1]}]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports {pc_out[0]}]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports {pc_out[1]}]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports {pc_out[2]}]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports {pc_out[3]}]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports {pc_out[4]}]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports {pc_out[5]}]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports {pc_out[6]}]
## set_property -dict {PACKAGE_PIN <pin> IOSTANDARD <std>} [get_ports {pc_out[7]}]
