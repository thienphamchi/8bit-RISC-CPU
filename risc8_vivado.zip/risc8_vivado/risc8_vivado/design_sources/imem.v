// =====================================================================
//  FILE        : imem.v
//  MODULE      : imem
//  PROJECT     : 8-bit RISC Processor Core with 5-Stage Pipeline
// ---------------------------------------------------------------------
//  WHAT THIS FILE DOES
//    Instruction Memory (program ROM): 256 words x 16 bits.
//    The PC is the address; the 16-bit instruction appears on 'instr'.
//    Separate instruction and data memories = HARVARD architecture, so
//    IF (Stage 1) and MEM (Stage 4) never fight over one memory.
//
//    The test program is BUILT INTO this file as a case statement, so
//    Vivado needs no external program.hex. Any address that is not
//    listed returns 0x0000 = NOP.
//
//  HOW TO CHANGE THE PROGRAM
//    Edit the lines inside the case statement: one line per address,
//    "8'hXX : instr = 16'hYYYY;". Encodings (see Document 00, section 3):
//      R-type : opcode | rd | rs1 | rs2 | 000
//      R1-type: opcode | rd | rs1 | 000000        (SHL SHR LD ST)
//      I-type : opcode | rd | 0 | imm8            (LDI ADDI)
//      J-type : opcode | 0000 | addr8             (JMP BZ BNZ)
//
//  WHO USES THIS FILE
//    -> Instantiated in risc8_5stage_core.v as "imem u_imem (...)"
//       (Stage 1, IF)
//
//  THIS FILE CALLS : nothing (leaf module, purely combinational ROM).
// =====================================================================

`timescale 1ns/1ps

module imem (
    input  wire [7:0]  addr,    // = PC
    output reg  [15:0] instr    // instruction at that address
);

    // Asynchronous read: instruction available in the same cycle.
    // 'default' guarantees every address has a value (no latch).
    always @(*) begin
        case (addr)
            // ---------- Part 1 : ALU operations and forwarding ----------
            8'h00 : instr = 16'h823C;   // LDI  R1, 0x3C
            8'h01 : instr = 16'h840F;   // LDI  R2, 0x0F
            8'h02 : instr = 16'h3650;   // AND  R3, R1, R2     R3 = 0x0C
            8'h03 : instr = 16'h4850;   // OR   R4, R1, R2     R4 = 0x3F
            8'h04 : instr = 16'h5AE0;   // XOR  R5, R3, R4     R5 = 0x33
            8'h05 : instr = 16'h6D40;   // SHL  R6, R5         R6 = 0x66
            8'h06 : instr = 16'h7F80;   // SHR  R7, R6         R7 = 0x33
            8'h07 : instr = 16'h2FE8;   // SUB  R7, R7, R5     R7 = 0, Z = 1
            8'h08 : instr = 16'hD00A;   // BZ   skip1 (0x0A)   taken
            8'h09 : instr = 16'h8EFF;   // LDI  R7, 0xFF       wrong path: flushed
            // ---------- Part 2 : loop, sum = 5+4+3+2+1 ----------
            8'h0A : instr = 16'h8205;   // skip1: LDI R1, 5    loop counter
            8'h0B : instr = 16'h8400;   // LDI  R2, 0          sum
            8'h0C : instr = 16'h8601;   // LDI  R3, 1          constant 1
            8'h0D : instr = 16'h1488;   // loop: ADD R2, R2, R1
            8'h0E : instr = 16'h2258;   // SUB  R1, R1, R3     sets Z at 0
            8'h0F : instr = 16'hE00D;   // BNZ  loop (0x0D)    taken 4 times
            // ---------- Part 3 : memory, carry, jump, halt ----------
            8'h10 : instr = 16'h8820;   // LDI  R4, 0x20       address 0x20
            8'h11 : instr = 16'hB500;   // ST   R2, [R4]       MEM[0x20] = 15
            8'h12 : instr = 16'hAB00;   // LD   R5, [R4]       R5 = 15
            8'h13 : instr = 16'h9AF0;   // ADDI R5, 0xF0       R5 = 0xFF (load-use)
            8'h14 : instr = 16'h9A01;   // ADDI R5, 1          R5 = 0, C = 1, Z = 1
            8'h15 : instr = 16'hC017;   // JMP  done (0x17)
            8'h16 : instr = 16'h8CEE;   // LDI  R6, 0xEE       wrong path: flushed
            8'h17 : instr = 16'hF000;   // done: HLT
            8'h18 : instr = 16'h8CAA;   // LDI  R6, 0xAA       never executed
            default: instr = 16'h0000;  // NOP
        endcase
    end

endmodule
